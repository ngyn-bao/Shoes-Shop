<!-- Footer -->
    <footer class="pt-5 pb-0">
      <div class="bottom-footer pt-4 pb-4 bg-dark text-white text-center">
        Shoes Shop © 2025
      </div>
    </footer>