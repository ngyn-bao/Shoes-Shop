    <!-- Footer start -->
    <footer class="pt-5 pb-0">
      <div class="top-footer pt-5">
        <div class="container">
          <div class="footer-content">
            <div class="row row1 pb-5">
              <div class="footer-item col-4">
                <h3 class="text-uppercase">get help</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
              <div class="footer-item col-4">
                <h3 class="text-uppercase">orders</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
              <div class="footer-item col-4">
                <h3 class="text-uppercase">register</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom-footer pt-5 pb-5">
        <div class="container">
          <div class="footer-content">
            <div class="row row2">
              <div class="footer-item col-4">
                <h3 class="text-uppercase">email sign up</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
              <div class="footer-item col-4">
                <h3 class="text-uppercase">gift cards</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
              <div class="footer-item col-4">
                <h3 class="text-uppercase">stores near you</h3>
                <ul>
                  <li>Contact Us</li>
                  <li>Shopping</li>
                  <li>NIKEID</li>
                  <li>Nike+</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- Footer end -->