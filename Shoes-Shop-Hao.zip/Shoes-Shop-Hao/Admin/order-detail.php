<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chi tiết đơn hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background:#f8f9fa; }
        .badge { font-size: 0.9rem; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0">Chi tiết đơn hàng <span id="orderIdDisplay">#</span></h4>
            <div>
                <a href="orders.php" class="btn btn-light btn-sm">Quay lại</a>
            </div>
        </div>
        <div class="card-body" id="content">
            <div class="text-center py-5">
                <div class="spinner-border text-primary" style="width:3rem;height:3rem;"></div>
                <div class="mt-3 fw-bold">Đang tải...</div>
            </div>
        </div>
    </div>
</div>

<script>
const params = new URLSearchParams(location.search);
const orderId = params.get('id');
if (!orderId) { alert('Thiếu ID'); location.href='orders.html'; }
document.getElementById('orderIdDisplay').textContent = '#' + orderId;

const API_DETAIL = `http://localhost/Shoes-Shop/api/Order/getOrderDetail.php?order_id=${orderId}`;
const API_RECALCULATE = `http://localhost/Shoes-Shop/api/Order/recalculateTotal.php`;

// Load chi tiết
async function load() {
    try {
        const res = await fetch(API_DETAIL);
        const json = await res.json();
        if (!json.success) throw new Error(json.message || 'Lỗi');

        const o = json.data.order;
        const items = json.data.items;

        const fPrice = n => Number(n).toLocaleString('vi-VN') + '₫';
        const fDate = d => new Date(d).toLocaleString('vi-VN');

        const statusText = {
            pending: 'Chờ xử lý', processing: 'Đang xử lý',
            shipped: 'Đã giao', delivered: 'Hoàn thành', cancelled: 'Đã hủy'
        }[o.status] || o.status;

        const statusClass = {
            pending: 'bg-warning text-dark', processing: 'bg-info text-white',
            shipped: 'bg-primary text-white', delivered: 'bg-success text-white',
            cancelled: 'bg-danger text-white'
        }[o.status] || 'bg-secondary';

        let rows = '';
        items.forEach((it, i) => {
            rows += `<tr>
                <td class="text-center">${i+1}</td>
                <td>
                    <div class="d-flex align-items-center gap-3">
                        <div>
                            <div class="fw-bold">${it.product_name}</div>
                            <small class="text-muted">ID: ${it.product_id}</small>
                        </div>
                    </div>
                </td>
                <td class="text-center fw-bold fs-5">${it.size}</td>
                <td class="text-center">${it.quantity}</td>
                <td class="text-end">${fPrice(it.price)}</td>
                <td class="text-end text-danger fw-bold">${fPrice(it.price * it.quantity)}</td>
            </tr>`;
        });

        document.getElementById('content').innerHTML = `
            <div class="row g-4 mb-4">
                <div class="col-lg-6">
                    <h5 class="border-bottom pb-2">Thông tin đơn hàng</h5>
                    <p><strong>Mã đơn:</strong> <span class="text-primary fs-4">#${o.order_id}</span></p>
                    <p><strong>Ngày đặt:</strong> ${fDate(o.created_at)}</p>
                    <p><strong>Trạng thái:</strong>
                        <span class="badge ${statusClass} px-3 py-2">${statusText}</span>
                    </p>
                    <p><strong>Tổng tiền:</strong>
                        <span class="text-danger fs-3 fw-bold">${fPrice(o.total_amount)}</span>
                    </p>
                </div>
                <div class="col-lg-6">
                    <h5 class="border-bottom pb-2">Thông tin khách hàng</h5>
                    <p><strong>Họ tên:</strong> ${o.fullname || 'Khách lẻ'}</p>
                    <p><strong>SĐT:</strong> ${o.phone || '—'}</p>
                    <p><strong>Địa chỉ:</strong> ${o.address || '—'}</p>
                </div>
            </div>

            <h5 class="border-bottom pb-2 mt-4">Chi tiết sản phẩm</h5>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>STT</th><th>Sản phẩm</th><th class="text-center">Size</th>
                            <th class="text-center">SL</th><th class="text-end">Giá</th><th class="text-end">Thành tiền</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>

            <div class="text-end mt-4">
                <button onclick="window.print()" class="btn btn-outline-secondary me-3">
                    <i class="bi bi-printer"></i> In đơn hàng
                </button>
            </div>
        `;
    } catch (e) {
        document.getElementById('content').innerHTML = `
            <div class="alert alert-danger text-center">
                <h5>Lỗi tải đơn hàng</h5>
                <p>${e.message}</p>
                <a href="orders.html" class="btn btn-secondary">Quay lại</a>
            </div>`;
    }
}

// Tính lại tổng tiền
async function recalculate() {
    if (!confirm('Tính lại tổng tiền theo chi tiết sản phẩm?')) return;

    try {
        const res = await fetch(API_RECALCULATE, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ order_id: orderId })
        });
        const json = await res.json();
        if (json.success) {
            alert('Đã cập nhật tổng tiền: ' + json.formatted);
            load(); // reload để thấy tổng mới
        } else {
            alert('Lỗi: ' + json.message);
        }
    } catch (err) {
        alert('Lỗi kết nối');
    }
}

load(); // chạy ngay
</script>
</body>
</html>